﻿public class DialogData 
{
	public DialogType Type { get; set; }

	public DialogData(DialogType type) 
	{
		this.Type = type;
	}
}
