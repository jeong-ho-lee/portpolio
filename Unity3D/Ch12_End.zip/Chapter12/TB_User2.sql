CREATE TABLE [dbo].[TB_User2] ( [UserID] int IDENTITY (1,1) NOT NULL, [Name] nvarchar(100) NULL,
[Level] int NULL,
[Exp] int NULL,
[Gold] int NULL,
[Ruby] int NULL,
[Point] int NULL,
[Created] datetime NULL,
[Deleted] int NULL,
PRIMARY KEY CLUSTERED ([UserID ASC])
);
