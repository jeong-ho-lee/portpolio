using UnityEngine;
using System.Collections;

namespace UnityEditor.XCodeEditor
{
	public class XCTarget : System.IDisposable
	{

		public void Dispose()
		{
			
		}
		
	}
}