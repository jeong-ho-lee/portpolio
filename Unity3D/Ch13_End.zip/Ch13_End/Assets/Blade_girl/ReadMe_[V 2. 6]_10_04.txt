

=====================================================

Blade girl_NPC [3D Model]    < V 2.6 > 9/2

=====================================================

Patch info  2014 10 4
-------------------------------------------------

1. Fixed problem that didn't move [Left Hand]'s Animation Key due to FBX version.

-------------------------------------------------






Update info   2014 8 20
--------------------------------------------------

1. It Has been upgraded to Unity 4.5.3

2. Fixed all model's bone node for macanim humanoid rig

3. Add 6 animation [Sliding], [Sleep], [Stun], [Down], [Up], [JumpAttack]

    
I am sorry to have kept you waiting.ㅠ_ㅠ !

-------------------------------------------------





* Attack explanation

-Attack 00

 This motion is wield a blade Quickly once.

-Attack

 This is ranged attack.
 This motion is collected energe at Blade,and
  Attack to enemy far away.
  
-Block

 This motion is  defend from enemy 's attack


-Attack01

 This motion is  defend from enemy 's attack(0F~15F Block), and Counter attack.
 
-combo

 This motion is attack three time in a row
 
 -Skil
 
  This motion is throw the blade on fire such as boomerang.
  
  -----------------------------------------------------
  
  

I'm very grateful to you and your company for buying my products and being my loyal customer^_^!!

 
 
------------------------------------------------------





< asset info >

-----------------------------------------------------
models _2 LOD
-----------------------------------------------------


>> 1 LOD


> 2227  tris (Include weapon: 50 tris)
   
> 1343   verts

> bipe set up



>> 2 LOD

> 1302 tris

> 863 verts

> bipe set up


----------------------------------------------------
Includes 45 Animations
----------------------------------------------------


> Idle

> Walk

> L_Walk

> R_Walk

> B_Walk

> Talk

> Talk01

> Run  [No draw blade]

> L_Run  [No draw blade]

> R_Run  [No draw blade]

> B_Run  [No draw blade]

> Jump [No draw blade]

> Draw blade

> Put blade

> Attack Standy

> Attack00

> Attack01

> Block

> BlockAttack

> Combo1

> Combo1_1

> Combo1_2

> Combo1_3

> Kick

> Skill

> M_Avoid

> L_Avoid

> R_Avoid

> Buff

> Run[draw blade]

> RunAttack[draw blade]

> L_Run[draw blade]

> R_Run[draw blade]

> B_Run[draw blade]

> Jump

> JumpAttack

> Sliding

> Sleep

> Stun

> Down

> Up

> Pick up

> Damage

> Death

> Dance [Gangam Style] !!!!


===================================================


=================================================== 

instructions

===================================================


1.click to the  [File] > [Open Project] > [Blade_Girl_NPC] folder

2.Dubble click [Demo_scene]

3.you can use the model file ~  Too easy~~~



Enjoy!! Cool Guys!!
================================================= 

If you have a question or comment

Send to my E-mail


kimys2848@naver.com

  

Visit my site for more info


>> http://blog.naver.com/kimys2848





