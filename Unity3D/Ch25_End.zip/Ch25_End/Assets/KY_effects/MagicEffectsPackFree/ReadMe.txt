Thank you to download the asset !
You can check the test scene of the "scene" folder in the "DEMO". 

It is within the "prefab" folder particle is being used in the demo. 
I offers a particle with reduced draw call to "primitive" folder within the "prefab" folder also. 

If you have imported my other effects series to one the project,
in common-used material (background image and scripts ...etc)  will be integrated, but does not disturb the operation.
Still if an error goes out, please prepare another project and download it once again.


I'm glad this asset when your serve you.
And I'm very glad when there is a review of you. 

My other particle effects :)
https://www.assetstore.unity3d.com/jp/#!/publisher/8804