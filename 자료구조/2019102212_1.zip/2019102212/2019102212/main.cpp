#include <iostream>
using namespace std;

const int MAX_ITEM = 5;
enum ITEM_RETURN { LESS, EQUAL, GREATER };

template <typename T>
class ItemType {
public:
	T data;
	T getData() const;
	void init(T _data);
	ITEM_RETURN CompareTo(const ItemType<T>& Item);
	bool operator<(const ItemType <T>& Item);
	bool operator>(const ItemType <T>& Item);

	T ItemType::getData() const {
		return data;
	}

	void init(T _data) {
		data = _data;
	}

	ITEM_RETURN CompareTo(const ItemType<T>& Item) {
		if (data < Item) return LESS;
		else if (data > Item) return GREATER;
		else return EQUAL;
	}

	bool operator<(const ItemType<T>& Item) {
		return data < Item;
	}

	bool operator>(const ItemType<T>& Item) {
		return data > Item;
	}
};

template <typename T>
class UnsortedType {
	ItemType<T> Items[MAX_ITEM];
	int currentPos = 0;
	int length = 0;
	UnsortedType();
	void print() const;
	bool IsFull() const;
	void MakeEmpty();
	void GetNextItem(ItemType<T>& Item);
	void ResetList();
	bool InsertItem(const ItemType<T>& Item);
	bool InsertData(T Data);
	bool DeleteData(T Data);
	bool DeleteItem(const ItemType<T>& Item);
	void RetreiveItem(ItemType<T>& Item, bool& IsFind);

	void print() const{
		for (int i = length; i; i--) {
			cout << Items[length - i] << " ";
		}
	}

	bool IsFull() const {
		return (length == MAX_ITEMS);
	}

	void MakeEmpty() {
		length = 0;
	}

	void GetNextItem(ItemType<T>& Item) {
		currentPos++;
		Item = Items[currentPos];
	}

	void ResetList() {
		currentPos = -1;
	}

	bool InsertItem(const ItemType<T>& Item) {
		Items[length] = Item;
		length++;

		return true;
	}

	bool InsertData(T Data) {
		return true;
	}

	bool DeleteData(T Data) {
		for (int = length; i; i--) {
			if (Items[i] == Data) {
				
			}
		}
		return true;
	}

	bool DeleteItem(const ItemType<T>& Item) {
		int location = 0;

		while (Item.CompareTo(Items[location]) != EQUAL) location++;
		Item[location] = Item[length - 1];
		length--;
		return true;
	}

	void RetreiveItem(ItemType<T>& Item, bool& IsFind) {

	}
};

template <typename T>
class SortedType : public UnsortedType {
	bool InsertItem(const ItemType<T>& Item);
	bool InsertData(T Data);
	bool DeleteData(T Data);

	bool InsertItem(const ItemType<T>& Item) {
		bool moreToSearch;
		int location = 0;

		moreToSearch = (location < length);
		while (moreToSearch) {
			switch (item.CompareTo(Items[location])) {
			case LESS: moreToSearch = false;
				break;
			case GREATER : location++;
				moreToSearch = false;
			}
		}

		for (int index = length; index > location; index--) Items[index] = Items[index - 1];
		Items[location] = Item;
		length++;
	}

	bool InsertData(T Data) {
		return true;
	}

	bool DeleteData(T Data) {
		int location = 0;

		while (Data.CompareTo(Items[location]) != EQUAL) location++;

		for (int index = location + 1; index < MAX_ITEMS; index++) ITEMS[index - 1] = ITEMS[index];
		length--;
		return true;
	}
};

int main() {

	return 0;
}