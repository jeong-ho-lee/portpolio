#include "Fraction.h"
#include <iostream>

int main() {
	CFraction fraction;
	
	std::cout << "The fraction object was created successfully." << std::endl;

	return 0;
}	