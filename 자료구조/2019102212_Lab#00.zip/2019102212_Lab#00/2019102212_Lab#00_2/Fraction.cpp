#include "Fraction.h"

CFraction::CFraction() {
	m_nNumerator = 0;
	m_nDenominator = 1;
}