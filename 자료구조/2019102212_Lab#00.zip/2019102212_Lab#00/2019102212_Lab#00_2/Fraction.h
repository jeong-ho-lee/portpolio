#pragma once

class CFraction {
private:
	int m_nNumerator;
	int m_nDenominator;
public:
	CFraction();
};