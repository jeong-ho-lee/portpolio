#include <iostream>
#include <fstream>
#include <stddef.h>
using namespace std;

template <typename ItemType>
struct TreeNode {
	ItemType info;
	TreeNode<ItemType>* left;
	TreeNode<ItemType>* right;
};

template <typename ItemType>
int CountNodes(TreeNode<ItemType>* tree) {
	if (tree == NULL) {
		return 0;
	}
	else {
		return CountNodes(tree->left) + CountNodes(tree->right) + 1;
	}
}

template <typename ItemType>
void Retrieve(TreeNode<ItemType>* ptr, ItemType& item, bool& found) {
	if (ptr == NULL) found = false;
	else if (item < ptr->info) Retrieve(ptr->left, item, found);
	else if (item > ptr->info) Retrieve(ptr->right, item, found);
	else {
		item = ptr->info;
		found = true;
	}
}

template <typename ItemType>
void Insert(TreeNode<ItemType>*& ptr, ItemType item) {
	if (ptr == NULL) {
		ptr = new TreeNode<ItemType>;
		ptr->right = NULL;
		ptr->left = NULL;
		ptr->info = item;
	}
	else if (item < ptr->info) Insert(ptr->left, item);
	else if (item > ptr->info) Insert(ptr->right, item);
}

template< class ItemType >
void Delete(TreeNode<ItemType>*& tree, ItemType item) {
	if (item < tree->info) Delete(tree->left, item);
	else if (item > tree->info) Delete(tree->right, item);
	else DeleteNode(tree);
}

template< class ItemType >
void GetPredecessor(TreeNode<ItemType>* tree, ItemType& data) {
	while (tree->right != NULL) tree = tree->right;
	data = tree->info;
}

template< class ItemType >
void DeleteNode(TreeNode<ItemType>*& tree) {
	ItemType data;
	TreeNode* tempPtr;
	tempPtr = tree;

	if (tree->left == NULL) {
		tree = tree->right;
		delete tempPtr;
	}
	else if (tree->right == NULL) {
		tree = tree->left;
		delete tempPtr;
	}
	else {
		GetPredecessor(tree->left, data);
		tree->info = data;
		Delete(tree->left, data);
	}
}

template< class ItemType >
void Print(TreeNode<ItemType>* ptr, ofstream& outFile) {
	if (ptr != NULL) {
		Print(ptr->left, outFile);
		outFile << ptr->info << '\n';
		Print(ptr->right, outFile);
	}
}

template< class ItemType >
void Destroy(TreeNode<ItemType>* ptr) {
	if (ptr != NULL) {
		Destroy(ptr->left);
		Destroy(ptr->right);
		delete ptr;
	}
}

template <typename ItemType>
class TreeType {
public:
	TreeType();
	~TreeType();
	TreeType(const TreeType& originalTree);
	void operator=(const TreeType& originalTree);
	void MakeEmpty();
	bool IsEmpty() const;
	bool IsFull() const;
	int LengthIs() const;
	void RetrieveItem(ItemType& item, bool& found) const;
	void InsertItem(ItemType item);
	void DeleteItem(ItemType item);
	void PrintTree(ofstream& outFile) const;
	int Imp_LeafCount();
private:
	TreeNode<ItemType>* root;
};

template <typename ItemType>
TreeType<ItemType>::TreeType() {
	
}

template <typename ItemType>
TreeType<ItemType>::~TreeType() {
	Destroy(root);
}


template <typename ItemType>
TreeType<ItemType>::TreeType(const TreeType& originalTree) {
	if (!originalTree.IsEmpty()) {
		root->info = originalTree.root->info;
		root->left(originalTree.root->left);
		root->right(originalTree.root->right);
	}
}

template <typename ItemType>
void TreeType<ItemType>::operator=(const TreeType& originalTree) {
	if (!originalTree.IsEmpty()) {
		root->info = originalTree.root->info;
		root->left = originalTree.root->left;
		root->right = originalTree.root->right;
	}

	Destroy(originalTree);
}

template <typename ItemType>
void TreeType<ItemType>::MakeEmpty() {
	Destroy(root);
}

template <typename ItemType>
bool TreeType<ItemType>::IsEmpty() const {
	return root == NULL;
}

template <typename ItemType>
bool TreeType<ItemType>::IsFull() const {
	TreeNode<ItemType>* location;
	try {
		location = new TreeNode<ItemType>;
		delete location;
		return false;
	}
	catch (bad_alloc exception) {
		return true;
	}
}

template <typename ItemType>
int TreeType<ItemType>::LengthIs() const {
	return CountNodes(root);
}

template <typename ItemType>
void TreeType<ItemType>::RetrieveItem(ItemType& item, bool& found) const {
	Retrieve(root, item, found);
}

template <typename ItemType>
void TreeType<ItemType>::InsertItem(ItemType item) {
	Insert(root, item);
}

template <typename ItemType>
void TreeType<ItemType>::DeleteItem(ItemType item) {
	Delete(root, item);
}

template <typename ItemType>
void TreeType<ItemType>::PrintTree(ofstream& outFile) const {
	Print(root, outFile);
}

template <typename ItemType>
int TreeType<ItemType>::Imp_LeafCount() {
	return CountNodes(root);
}

int main() {
	ofstream fout;
	fout.open("Tree.txt");

	TreeType<int> tree1;

	tree1.InsertItem(4);
	tree1.InsertItem(2);
	tree1.InsertItem(6);
	tree1.InsertItem(1);
	tree1.InsertItem(3);
	tree1.InsertItem(5);
	tree1.InsertItem(7);

	cout << tree1.Imp_LeafCount() << '\n';

	fout.close();

	return 0;
}