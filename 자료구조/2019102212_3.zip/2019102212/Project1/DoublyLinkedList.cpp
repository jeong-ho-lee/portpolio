#include "DoublyLinkedList.h"
#include <iostream>

DoublyLinkedList::DoublyLinkedList() {
	header = new NodeType;
	listData->next = header;
	header->back = listData;
	trailer = new NodeType;
	header->next = trailer;
	trailer->back = header;
	length = 0;
	currentPos = header;
}

DoublyLinkedList::DoublyLinkedList(DoublyLinkedList& DLL) {
	DoublyLinkedList result;

	while (DLL.currentPos != NULL) {
		currentPos = currentPos->next;
		result.InsertItem(currentPos->info);
	}
}

DoublyLinkedList::~DoublyLinkedList() {
	NodeType* temp = new NodeType;
	while (header->next == trailer) {
		temp = header;
		header = header->next;
		delete temp;
	}
	delete header;
	delete trailer;
}

int DoublyLinkedList::LengthIs() const {
	return length;
}

void DoublyLinkedList::RetrieveItem(int& item, bool& found) {
	bool moreToSearch;
	NodeType* location;
	location = listData;
	found = false;
	moreToSearch = (location != NULL);
	while (moreToSearch && !found)
	{
		if (item == location->info)
		{
			found = true;
			item = location->info;
		}
		else
		{
			location = location->next;
			moreToSearch = (location != NULL);
		}
	}
}

void DoublyLinkedList::InsertItem(int item) {
	NodeType* location;
	location = new NodeType;
	location->info = item;
	location->next = header->next;
	header->next->back = location;
	header = location;
	listData->next = header;
	length++;
}

void DoublyLinkedList::DeleteItem(int item) {
	NodeType* temp;
	temp = header;
	while (temp->info == item) {
		temp = temp->next;
	}
	NodeType* erase;
	erase = temp;

	temp->back->next = temp->next;
	temp->next->back = temp->back;

	delete erase;
}

void DoublyLinkedList::ResetList() {
	currentPos = header;
}

void DoublyLinkedList::GetNextItem(int& item) {
	currentPos = currentPos->next;
	item = currentPos->info;
}

void DoublyLinkedList::GetBackItem(int& item) {
	currentPos = currentPos->back;
	item = currentPos->info;
}

void DoublyLinkedList::Top(NodeType* node) {
	node = listData->next;
}

DoublyLinkedList DoublyLinkedList::Pick() {
	NodeType* temp = header;
	DoublyLinkedList result;
	char input = '0';

	while (input != 'Q') {
		std::cout << "Enter Command - I : Insert, N : Next, B : Back, Q : Quit - ";
		std::cin >> input;

		if (input == 'I') result.InsertItem(temp->info);
		else if (input == 'N') temp = temp->next;
		else if (input == 'B') temp = temp->back;
		else std::cout << "Wrond Command\n";
	}

	return result;
}