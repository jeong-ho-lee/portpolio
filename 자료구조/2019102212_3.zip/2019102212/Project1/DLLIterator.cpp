#include "DLLIterator.h"

DLLIterator::DLLIterator(DoublyLinkedList& dll) : DLL(dll) { dll.Top(current); }

DLLIterator::~DLLIterator() {
	
}

bool DLLIterator::NotNull() {
	return true;
}

bool DLLIterator::NextNotNull() {
	return true;
}

void DLLIterator::ResetDLL() {
	DLL.ResetList();
	DLL.Top(current);
}

void DLLIterator::GetCurrentItem(int& item) {
	item = current->info;
}

void DLLIterator::GetNextItem(int& item) {
	current = current->next;
	item = current->info;
}

void DLLIterator::GetPrevItem(int& item) {
	current = current->back;
	item = current->info;
}