#pragma once
#include "stddef.h"

struct NodeType
{
	int info;
	NodeType* next;
	NodeType* back;
};


class DoublyLinkedList {
public:
	DoublyLinkedList();
	DoublyLinkedList(DoublyLinkedList& DLL);
	~DoublyLinkedList();
	int LengthIs() const;
	void RetrieveItem(int& item, bool& found);
	void InsertItem(int item);
	void DeleteItem(int item);
	void ResetList();
	void GetNextItem(int& item);
	void GetBackItem(int& item);
	void Top(NodeType* node);
	DoublyLinkedList Pick();
private:
	NodeType* listData;
	int length;
	NodeType* currentPos;
	NodeType* header;
	NodeType* trailer;
};