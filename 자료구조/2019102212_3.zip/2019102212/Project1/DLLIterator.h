#pragma once
#include "DoublyLinkedList.h"

class DLLIterator : protected DoublyLinkedList {
public:
	DLLIterator(DoublyLinkedList& dll);
	~DLLIterator();
	bool NotNull();
	bool NextNotNull();
	void ResetDLL();
	void GetCurrentItem(int& item);
	void GetNextItem(int& item);
	void GetPrevItem(int& item);
private:
	DoublyLinkedList& DLL;
	NodeType* current;
};