class FullPQ{};
class EmptyPQ{};
#include "heap.h"
#include "SortedType.h"
template<class ItemType>
class PQType
{
public:
  PQType(int);
  ~PQType();
  
  void MakeEmpty();  
  bool IsEmpty() const;
  bool IsFull() const;
  void Enqueue(ItemType newItem);
  void Dequeue(ItemType& item);
private:
  int length;
  HeapType<ItemType> items;
  int maxItems;
  friend struct HeapType<ItemType>;
};

template<class ItemType>
PQType<ItemType>::PQType(int max)
{
  maxItems = max;
  items.elements = new ItemType[max];
  length = 0;
}

template<class ItemType>
void PQType<ItemType>::MakeEmpty()
{
  length = 0;
}

template<class ItemType>
PQType<ItemType>::~PQType()
{
  delete [] items.elements;
}
template<class ItemType>
void PQType<ItemType>::Dequeue(ItemType& item)
{
  if (length == 0)
    throw EmptyPQ();
  else
  {
    item = items.elements[0];
    items.elements[0] = items.elements[length-1];
    length--;
    items.ReheapDown(0, length-1);
  }
}

template<class ItemType>
void PQType<ItemType>::Enqueue(ItemType newItem)
{
  if (length == maxItems)
    throw FullPQ();
  else
  {
    length++;
    items.elements[length-1] = newItem;
    items.ReheapUp(0, length-1);
  }
}
template<class ItemType>
bool PQType<ItemType>::IsFull() const
{
  return length == maxItems;
}

template<class ItemType>
bool PQType<ItemType>::IsEmpty() const
{
  return length == 0;
}

class FullPQLL {};
class EmptyPQLL {};
template <class ItemType>
class PQLLType {
public:
	PQLLType();
	~PQLLType();
	void MakeEmpty();
	bool IsEmpty() const;
	bool IsFull() const;
	void Enqueue(ItemType newItem);
	void Dequeue(ItemType &item);
	void Print();
private:
	int length;
	SortedType<ItemType> linkedlist;
};

template<class ItemType>
PQLLType<ItemType>::PQLLType()
{
	length = 0;
}

template<class ItemType>
void PQLLType<ItemType>::MakeEmpty()
{
	length = 0;
}

template<class ItemType>
PQLLType<ItemType>::~PQLLType() {}
template<class ItemType>
void PQLLType<ItemType>::Dequeue(ItemType& item)
{
	if (length == 0) {
		throw EmptyPQLL();
	}
	else {
		linkedlist.ResetList();
		linkedlist.GetNextItem(item);
		linkedlist.DeleteItem(item);
		length--;
	}
}

template<class ItemType>
void PQLLType<ItemType>::Enqueue(ItemType newItem)
{
	if (linkedlist.IsFull()) {
		throw FullPQLL();
	}
	else {
		length++;
		linkedlist.InsertItem(newItem);
	}
}
template<class ItemType>
bool PQLLType<ItemType>::IsFull() const
{
	return linkedlist.IsFull();
}

template<class ItemType>
bool PQLLType<ItemType>::IsEmpty() const
{
	return length == 0;
}