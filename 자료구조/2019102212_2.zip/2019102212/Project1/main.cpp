#include "CircularQue.cpp"
#include <iostream>
using namespace std;

int main() {
	CircularQue<int> Que;

	Que.EnQue(5);
	Que.EnQue(4);
	Que.EnQue(3);

	int temp;
	Que.DeQue(temp);

	return 0;
}