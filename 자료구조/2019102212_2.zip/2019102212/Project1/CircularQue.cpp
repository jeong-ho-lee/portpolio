#include "CircularQue.h"

template<typename ItemType>
CircularQue<ItemType>::CircularQue(int max_item) {
	max = max_item + 1;
	front = max - 1;
	rear = max - 1;
	m_items = new ItemType[max];
}

template<typename ItemType>
CircularQue<ItemType>::~CircularQue() {
	delete[] m_items;
}

template<typename ItemType>
bool CircularQue<ItemType>::isEmpty() const {
	return (front == rear);
}

template<typename ItemType>
bool CircularQue<ItemType>::isFull() const {
	return (front == (rear + 1) % max);
}

template<typename ItemType>
bool CircularQue<ItemType>::EnQue(const ItemType& input) {
	/*if (isFull()) return false;
	else {
		rear = (rear + 1) % max;
		m_items[rear] = input;
		return true;
	}*/
	if (isFull()) {
		front = (front + 1) % max;
		rear = (rear + 1) % max;
		m_items[rear] = input;
		return true;
	}
}

template<typename ItemType>
bool CircularQue<ItemType>::DeQue(ItemType& output) {
	/*if (isEmpty()) return false;
	else {
		front = (front + 1) % max;
		output = m_items[front];
	}*/
	if (isEmpty()) return false;
	else {
		rear = rear - 1;
		if (rear < 0) rear += max;
		output = m_items[rear];
		return true;
	}
}

template<typename ItemType>
CircularQue<ItemType>::CircularQue(const CircularQue& org) {
	CircularQue<ItemType> temp;
	CircularQue<ItemType> result;

	while (!org.isEmpty()) {
		ItemType item;
		org.DeQue(item);
		temp.EnQue(item);
	}

	while (!temp.isEmpty()) {
		ItemType item;
		temp.DeQue(item);
		result.EnQue(item);
		org.EnQue(item);
	}

	return result;
}

template<typename ItemType>
CircularQue<ItemType>& CircularQue<ItemType>::operator=(const CircularQue& org) {
	CircularQue<ItemType> temp;
	CircularQue<ItemType> result;

	while (!org.isEmpty()) {
		ItemType item;
		org.DeQue(item);
		temp.EnQue(item);
	}

	while (!temp.isEmpty()) {
		ItemType item;
		temp.DeQue(item);
		result.EnQue(item);
		org.EnQue(item);
	}

	return result;
}