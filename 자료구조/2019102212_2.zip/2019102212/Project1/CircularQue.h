#pragma once

template<typename ItemType>
class CircularQue {
private:
	ItemType* m_items;
	int front;
	int rear;
	int max;
public:
	CircularQue(int max_item = 10);
	~CircularQue();
	bool isEmpty() const;
	bool isFull() const;
	bool EnQue(const ItemType& input);
	bool DeQue(ItemType& output);
	CircularQue(const CircularQue& org);
	CircularQue<ItemType>& operator=(const CircularQue& org);
};